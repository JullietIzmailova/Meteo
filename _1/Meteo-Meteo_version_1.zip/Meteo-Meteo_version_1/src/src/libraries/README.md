We checked these libraries to work with our drivers. 
All tests were done using them. 
Unpack and put in Arduino Studio/Libraries forlder



DHT sensor library 1.3.4: https://github.com/adafruit/DHT-sensor-library

LiquidCrystal_I2C 1.1.4: https://github.com/marcoschwartz/LiquidCrystal_I2C


