
bool LED_Setup();

bool LED_RED_Setup();
bool LED_GREEN_Setup();
bool LED_YELLOW_Setup();

void LED_Red_Set_Light(bool on);
void LED_Green_Set_Light(bool on);
void LED_Yellow_Set_Light(bool on);

void LED_Only_Red_Set_Light();
void LED_Only_Green_Set_Light();
void LED_Only_Yellow_Set_Light();