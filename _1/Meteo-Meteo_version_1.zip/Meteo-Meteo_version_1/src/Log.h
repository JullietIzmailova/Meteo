#ifndef LOG_H
#define LOG_H

#include <Arduino.h>

void Log(String text);

#endif