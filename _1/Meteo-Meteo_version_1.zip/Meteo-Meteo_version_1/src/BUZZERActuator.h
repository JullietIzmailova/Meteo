bool BUZZER_Setup();

void BUZZER_Set_sound(bool on);