bool LIGHT_Setup();

float LIGHT_GET_data();

bool LIGHT_SENSOR_ANALOG_Setup();
bool LIGHT_SENSOR_DIGITAL_Setup();